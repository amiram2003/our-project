#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 8000000UL
#include <util/delay.h>
#include "LED.h"
#include "std_macros.h"

// هيفضل هنا كلاس الـ InterruptManager والـ LED والـ LEDController زي ما انتي عاملاهم بالظبط

// ... (ضعي الكلاسات الخاصة بكِ هنا) ...

int main(void) {
    // إعداد أرجل الـ Interrupt كمدخلات (مهم جداً للـ ATmega32)
    CLR_BIT(DDRD, 2); // INT0
    CLR_BIT(DDRD, 3); // INT1
    CLR_BIT(DDRB, 2); // INT2

    InterruptManager::enableGlobalInterrupts();
    InterruptManager::configureINT0(InterruptManager::RISING_EDGE);
    InterruptManager::configureINT1(InterruptManager::RISING_EDGE);
    InterruptManager::configureINT2(InterruptManager::RISING_EDGE);

    while (1) {
        ledController.turnOffAll();
    }
}

ISR(INT0_vect) { ledController.turnOnLED(0); }
ISR(INT1_vect) { ledController.turnOnLED(1); }
ISR(INT2_vect) { ledController.turnOnLED(2); }