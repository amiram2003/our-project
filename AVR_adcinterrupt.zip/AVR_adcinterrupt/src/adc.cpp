#ifndef ADC_DRIVER_CPP_H_
#define ADC_DRIVER_CPP_H_

#include <avr/io.h>
#include "std_macros.h"

class ADC_Driver {
public:
    // تهيئة المحول التماثلي الرقمي
    static void init() {
        SET_BIT(ADMUX, REFS0);    // AVCC reference
        SET_BIT(ADCSRA, ADEN);    // enable ADC
        // prescaler = 64
        SET_BIT(ADCSRA, ADPS1);
        SET_BIT(ADCSRA, ADPS2);
    }

    // قراءة قيمة ADC
    static unsigned short read() {
        SET_BIT(ADCSRA, ADSC);             // start conversion
        while(GET_BIT(ADCSRA, ADSC));      // wait until finish
        return ADC;                         // قراءة النتيجة
    }
};

#endif