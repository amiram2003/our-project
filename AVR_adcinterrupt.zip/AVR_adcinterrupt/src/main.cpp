#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "LED.hpp"
#include "ADC.hpp"

// إنشاء كائنات
ADC adc;
LED led0('D',0);
LED led1('D',1);

int main()
{
    adc.init();        // تهيئة ADC
    sei();             // تفعيل المقاطعات العامة

    while(1)
    {
        adc.startConversion(); // بدء التحويل
        _delay_ms(1);

        // مثال تشغيل LED1 و LED2 بالتناوب
        led1.on();
        led0.off();
        _delay_ms(1000);

        led1.off();
        led0.on();
        _delay_ms(1000);
    }

    return 0;
}

// ISR ADC
ISR(ADC_vect)
{
    PORTD = 0x01;   // يمكن تعديل هذا حسب ما تريد
    // _delay_ms(1000); // لا يفضل وضع delay داخل ISR
}