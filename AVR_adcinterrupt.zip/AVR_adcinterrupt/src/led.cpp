#include <avr/io.h>
#include "std_macros.h"
#include "LED.hpp"

void LED_vInit(char port, char pin)
{
    switch(port)
    {
        case 'A':
            SET_BIT(DDRA,pin);
        break;

        case 'B':
            SET_BIT(DDRB,pin);
        break;

        case 'C':
            SET_BIT(DDRC,pin);
        break;

        case 'D':
            SET_BIT(DDRD,pin);
        break;
    }
}

void LED_vTurnOn(char port, char pin)
{
    switch(port)
    {
        case 'A':
            SET_BIT(PORTA,pin);
        break;

        case 'B':
            SET_BIT(PORTB,pin);
        break;

        case 'C':
            SET_BIT(PORTC,pin);
        break;

        case 'D':
            SET_BIT(PORTD,pin);
        break;
    }
}

void LED_vTurnOff(char port, char pin)
{
    switch(port)
    {
        case 'A':
            CLR_BIT(PORTA,pin);
        break;

        case 'B':
            CLR_BIT(PORTB,pin);
        break;

        case 'C':
            CLR_BIT(PORTC,pin);
        break;

        case 'D':
            CLR_BIT(PORTD,pin);
        break;
    }
}