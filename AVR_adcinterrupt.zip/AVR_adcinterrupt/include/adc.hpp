#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_

class ADC_Driver {
public:
    // دالة لتهيئة الـ ADC
    void init();

    // دالة لقراءة قيمة الـ ADC
    unsigned short read();
};

#endif
