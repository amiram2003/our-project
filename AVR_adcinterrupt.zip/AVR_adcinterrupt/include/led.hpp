#ifndef LED_H_
#define LED_H_

#ifdef __cplusplus
extern "C" {
#endif

void LED_vInit(char port, char pin);
void LED_vTurnOn(char port, char pin);
void LED_vTurnOff(char port, char pin);

#ifdef __cplusplus
}
#endif

#endif